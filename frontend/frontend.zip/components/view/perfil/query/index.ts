import GET_MY_USUARIO from "./GET_MY_USUARIO";
import UPDATE_MY_USUARIO from "./UPDATE_MY_USUARIO";
import { RESET_PASS_WITH_TOKEN } from "@/query";

export {
    GET_MY_USUARIO,
    UPDATE_MY_USUARIO,
    RESET_PASS_WITH_TOKEN
};