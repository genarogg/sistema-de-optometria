'use client';

import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { actualizarPlanService } from '../service/actualizarPlan.service';
import { useToast } from '@/hooks/use-toast';
import { Plan } from '@/global/customTypes';

interface ModalEditarPlanProps {
  isOpen: boolean;
  onClose: () => void;
  plan: Plan | null;
  onSuccess?: () => void;
}

export default function ModalEditarPlan({
  isOpen,
  onClose,
  plan,
  onSuccess,
}: ModalEditarPlanProps) {
  const [tipo, setTipo] = useState('');
  const [costo, setCosto] = useState('');
  const [estatus, setEstatus] = useState('activo');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (plan) {
      setTipo(plan.tipo);
      setCosto(plan.costo?.toString() || '');
      setEstatus(plan.estatus || 'activo');
    }
  }, [plan, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!tipo || !costo || !plan?.id) {
      toast({
        title: 'Error',
        description: 'Por favor completa todos los campos',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    try {
      await actualizarPlanService(plan.id, {
        tipo,
        costo: parseFloat(costo),
        estatus,
      });

      toast({
        title: 'Éxito',
        description: 'Plan actualizado correctamente',
      });

      onClose();
      onSuccess?.();
    } catch (error) {
      console.error('[v0] Error updating plan:', error);
      toast({
        title: 'Error',
        description: 'No se pudo actualizar el plan',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Editar Plan</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="tipo">Tipo de Plan</Label>
            <Input
              id="tipo"
              placeholder="Ej: Plan Premium"
              value={tipo}
              onChange={(e) => setTipo(e.target.value)}
              disabled={isLoading}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="costo">Costo</Label>
            <Input
              id="costo"
              type="number"
              step="0.01"
              placeholder="Ej: 99.99"
              value={costo}
              onChange={(e) => setCosto(e.target.value)}
              disabled={isLoading}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="estatus">Estado</Label>
            <Select value={estatus} onValueChange={setEstatus} disabled={isLoading}>
              <SelectTrigger id="estatus">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="activo">Activo</SelectItem>
                <SelectItem value="inactivo">Inactivo</SelectItem>
                <SelectItem value="pendiente">Pendiente</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex gap-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isLoading}
            >
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? 'Actualizando...' : 'Actualizar Plan'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
