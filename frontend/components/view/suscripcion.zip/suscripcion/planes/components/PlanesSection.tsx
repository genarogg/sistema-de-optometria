'use client';

import React, { useEffect, useState } from 'react';
import { useIsMobile } from '@/hooks/use-mobile';
import TablaPlan from './TablaPlan';
import TarjetaPlan from './TarjetaPlan';
import ModalCrearPlan from './ModalCrearPlan';
import PlanesBuscador from './PlanesBuscador';
import { usePlaneFilters } from '../hook/usePlaneFilters';
import { getPlanesService } from '../service/getPlanes.service';
import planesStore  from '../store/planesStore';
import { useShallow } from 'zustand/react/shallow';


export default function PlanesSection() {
  const isMobile = useIsMobile()
  const [isLoading, setIsLoading] = useState(true);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  const { planes, setPlanes } = planesStore(
    useShallow((state) => ({
      planes: state.planes,
      setPlanes: state.setPlanes,
    }))
  );

  const {
    filteredPlanes,
    searchTerm,
    setSearchTerm,
    statusFilter,
    setStatusFilter,
  } = usePlaneFilters(planes);

  useEffect(() => {
    const loadPlanes = async () => {
      setIsLoading(true);
      try {
        const data = await getPlanesService();
        setPlanes(data);
      } catch (error) {
        console.error('[v0] Error loading planes:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadPlanes();
  }, [setPlanes]);

  const handleRefresh = async () => {
    setIsLoading(true);
    try {
      const data = await getPlanesService();
      setPlanes(data);
    } catch (error) {
      console.error('[v0] Error refreshing planes:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <PlanesBuscador
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        statusFilter={statusFilter}
        onStatusChange={setStatusFilter}
        onCreateClick={() => setIsCreateModalOpen(true)}
      />

      {isMobile ? (
        <TarjetaPlan
          planes={filteredPlanes}
          onEdit={() => handleRefresh()}
          onDelete={() => handleRefresh()}
        />
      ) : (
        <TablaPlan
          planes={filteredPlanes}
          onEdit={() => handleRefresh()}
          onDelete={() => handleRefresh()}
        />
      )}

      <ModalCrearPlan
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onSuccess={() => handleRefresh()}
      />
    </div>
  );
}
