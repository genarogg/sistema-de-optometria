import { useState, useMemo } from 'react';
import { Plan } from '@/global/customTypes';

export interface PlaneFilters {
  searchTerm: string;
  statusFilter: string;
}

export function usePlaneFilters(planes: Plan[]) {
  const [filters, setFilters] = useState<PlaneFilters>({
    searchTerm: '',
    statusFilter: 'todos',
  });

  const filteredPlanes = useMemo(() => {
    return planes.filter((plan) => {
      const matchesSearch =
        plan.tipo.toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
        plan.id.toString().includes(filters.searchTerm);

      const matchesStatus =
        filters.statusFilter === 'todos' ||
        plan.estatus?.toLowerCase() === filters.statusFilter.toLowerCase();

      return matchesSearch && matchesStatus;
    });
  }, [planes, filters]);

  return {
    filters,
    setFilters,
    filteredPlanes,
    searchTerm: filters.searchTerm,
    setSearchTerm: (term: string) =>
      setFilters((prev) => ({ ...prev, searchTerm: term })),
    statusFilter: filters.statusFilter,
    setStatusFilter: (status: string) =>
      setFilters((prev) => ({ ...prev, statusFilter: status })),
  };
}
